@echo off
cd /d "%~dp0"
start "Syndicate HD" "%~dp0Syndicate-HD.exe" -m 1
