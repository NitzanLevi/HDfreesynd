@echo off
cd /d "%~dp0"
setlocal
set "SYNDICATE_SHOW_INTRO=1"
start "Syndicate HD" "%~dp0Syndicate-HD.exe" -u user
